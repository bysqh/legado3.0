package io.legado.app.lib.aliyun

object ALiYun {

    fun getToken() {

    }


}